from sage_extensions.all import *
from sage.symbolic.ring import SR
from sage.rings.infinity import Infinity
M = SmoothManifolds()(1, 'germ composition')
U = M.chart('U', 't')
A = M.smooth_functions()
X = M.tangent_bundle().sections().coordinate_vector_field(U, 0)
def jets(chart, point, alpha):
    t = point.coordinates()[0]
    return (t*t + RR(1), RR(2)*t, RR(2))[alpha[0]] if alpha[0] <= 2 else RR(0)
f = A.from_local_derivatives(jets)
z = SR.var('z')
g = C(Infinity, RR, RR)((z**3+z).function(z))
h = g.compose(f)
p = M((2,))
assert h.parent() is A
assert h(p) == RR(130)
print('composition value at 2 = 130', flush=True)
assert X(h)(p) == RR(304)
assert X(X(h))(p) == RR(632)
print('first and second derivative of composition = 304, 632', flush=True)
