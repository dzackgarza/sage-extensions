# Reproduction and validation

Isolated detached checkout: `/home/dzack/gitclones/sage-extensions/.scratch/worker318-k606`.
Base: unpublished local worker-290 commit `37a6548b6b37930191040cc6ad301ac8872fef60`
(parent `e2803c36a8a316337071ba90551ce770d36b2b86`, the then-fetched remote main).
No owner-tree files were edited, no temporary Sage was installed, and nothing
was pushed. Runtime was the existing `sage-research` container (Sage 11.0.beta5).

Exact common invocation (host bash, from this isolated checkout):

```bash
export DOCKER_HOST=unix:///run/user/$(id -u)/docker.sock
set -o pipefail
timeout 180 /home/dzack/bin/docker exec -w /repos/sage-extensions/.scratch/worker318-k606 \
  -e PYTHONPATH=/repos/sage-extensions/.scratch/worker318-k606/src:/home/dzack/ai-review-ci/tool-artifacts/pytest_plugins \
  -e PYTHONNOUSERSITE=1 sage-research /sage/.venv/bin/python \
  -c 'import sage.all,sys,pytest; print("runtime",sage.version.version,flush=True); sys.exit(pytest.main(sys.argv[1:]))' \
  -p qc_sage_session --no-time-gates -q <test paths> 2>&1 | tee results/issue-606/worker-318/<log>
```

The timeout bound for the final cover test was 120 seconds. Time gates were
disabled, not assertions. All paths below are in `tests/objects/`.

- `baseline-original.log`: original circle and stereographic quotient tests at
  e2803c36, 9 passed and 2 failed (19.51 s). These failures were manifold function
  restriction/admission, not violations of the smooth tangent theorem.
- `restriction-candidate-2.log`: original
  test_the_stereographic_transition_of_the_sphere_is_a_quotient_of_sections.sage,
  6 passed (14.48 s) after the restriction-owner fix.
- `noncompact-red.log`: new
  test_a_derivation_is_local_on_a_noncompact_multichart_manifold.sage (one test
  at that revision), 1 failed (11.83 s), with the previous global-family inverse.
- `derivation-candidate.log`: 5 passed, 1 timed out (145.25 s) in the old
  compact bump-family symbolic circle bracket path.
- `local-inverse-candidate.log`: 20 passed (26.13 s), at the revision before
  the later pullback and frame refinements, using
  test_a_derivation_is_local_on_a_noncompact_multichart_manifold.sage,
  test_a_derivation_of_a_one_chart_manifold_is_a_section.sage,
  test_a_derivation_of_the_circle_is_the_section_it_differentiates_along.sage,
  test_a_smooth_function_s_on_a_manifold_carries_its_chart_expressions.sage,
  test_the_tangent_bundle_of_the_circle_is_trivial.sage,
  test_the_stereographic_transition_of_the_sphere_is_a_quotient_of_sections.sage.
- `pullback-germs-candidate.log`: 21 passed, 1 failed (59.77 s), using
  test_a_section_pulls_back_from_a_different_cover.sage,
  test_a_section_pulls_back_along_a_constant_map_of_the_circle.sage,
  test_a_section_of_a_pullback_is_stated_on_its_own_base.sage,
  test_a_vector_field_pulls_back_along_a_smooth_map.sage,
  test_the_functions_of_the_base_scale_a_pullback_section.sage,
  test_a_pullback_agreement_reads_every_component_of_the_bundle.sage.
  The sole failure is the mathematically false literal reflection fixture;
  see source-proof.md.
- `full-candidate.log`: exact broad selector below, 72 collected, host
  exit 124 (180-second timeout), two failures among progress markers.
  This is not a passing run. It started before the corrected reflection test
  and the last common-refinement changes.

```bash
$(find tests/objects -maxdepth 1 -type f | grep -E 'test_(a_(bump_of_a_chart|derivation_is_local|derivation_of_a_one_chart|derivation_of_the_circle|frame_is_nowhere|frame_reads|pullback_agreement|section_is_stated|section_of_a_pullback|section_pulls_back|section_stated_on_a_cover|smooth_function_s_on_a_manifold|trivialization_reads|vector_field_pulls_back)|the_(frame_of_a_two_chart|functions_of_the_base_scale|proper_chart_domain|real_line_is_a_smooth|stereographic_transition_of_the_sphere|tangent_bundle_of_the_circle|tangent_bundle_restricts))' | sort)
```

- `new-regressions.log`: new noncompact file and corrected reflection file,
  4 passed and 1 failed (26.75 s). The flat-function derivative and frame
  roundtrip, and nonsymbolic smooth map pullback, passed; both reflection
  regressions passed. The new distinct-cover test initially used a scalar
  subtraction incompatible with the owned algebra.
- `common-refinement.log`: new noncompact file with
  `-k 'distinct_covers or independently_indexed'`, 1 passed and 1 failed,
  2 deselected (20.12 s). Direct pullback section on independently indexed
  cover passed. Distinct-cover frame certification failed because raw
  symbolic guards were passed to the owned cover certificate; repaired
  subsequently by raising guards back to chart functions.
- `cover-final.log`: new noncompact file, original
  test_a_section_is_stated_on_a_cover_of_the_manifold.sage, corrected
  test_a_section_of_a_pullback_is_stated_on_its_own_base.sage.
  See the final result appended below.

`cover-final.log`: **8 passed, 1 failed (51.56 s)**. All four new
regressions passed, as did both corrected reflection tests and the two
other original covering tests. The failure was the original
test_a_family_that_does_not_cover_the_manifold_is_refused: the
one-stereographic-chart family on S^1 is provably incomplete, but the
existing coverage solver raised CoverageUndecided instead of the
required AssertionError. Added the known exact missing-pole witness
for the standard sphere; this does not extrapolate a general negative
decision from a failed positive certificate.

`cover-obstruction-final.log`: 5 passed (44.05 s), using
test_a_section_is_stated_on_a_cover_of_the_manifold.sage and the corrected
test_a_section_of_a_pullback_is_stated_on_its_own_base.sage; timeout 120 s.
The noncoverage regression now passes. Performance gates were disabled
as above; the log reports 26.35 s versus 20 s for the first test,
as well as import/collection above their ceilings.
The entire broad suite has not completed on the final code.
Python compilation and git diff --check passed. Full acceptance not met.
