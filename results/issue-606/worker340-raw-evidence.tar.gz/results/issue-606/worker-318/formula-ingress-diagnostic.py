from sage_extensions.all import *
from sage.symbolic.ring import SR
from sage.rings.infinity import Infinity
from sage.repl.preparse import preparse
from sageparse.preparser import runtime_namespace
print('public Gaussian declaration:', preparse('g(t) = exp(-t^2)'),flush=True)
env=dict(globals());env.update(runtime_namespace())
try:
    exec(preparse('g(t) = exp(-t^2)'),env)
except TypeError as exc:
    print('declaration failure:',exc,flush=True)
else:
    print('declared',env['g'],flush=True)
t=SR.var('t')
formula=SR.exp(-t*t) if hasattr(SR,'exp') else exp(-t*t)
print('engine formula',formula,flush=True)
g= C(Infinity,RR,RR)(formula.function(t))
assert g.parent() is C(Infinity,RR,RR)
assert g(RR(0)) == RR(1)
assert g.derivative()(RR(0))==RR(0)
assert g.derivative().derivative()(RR(0))==RR(-2)
print('Gaussian evaluation and two derivatives verified',flush=True)
