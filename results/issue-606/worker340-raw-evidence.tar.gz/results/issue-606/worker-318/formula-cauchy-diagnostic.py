from sage_extensions.all import *
from sage.symbolic.ring import SR
from sage.ext.fast_callable import fast_callable
from sage.rings.infinity import Infinity
a=Sets().Mor(NN,QQ)(lambda n: QQ(5)+QQ(1)/QQ(2)**int(n))
p=RR.of_cauchy(a)
x=SR.var("x")
body=x**3+x
f=C(Infinity,RR,RR)(body.function(x))
try:
    result=f(p)
    print('current native formula result',result,flush=True)
except (TypeError,ValueError,AssertionError,NotImplementedError) as exc:
    print('current formula evaluation fails',type(exc).__name__,str(exc),flush=True)
print('exact field fast_callable polynomial:',flush=True)
v=fast_callable(body, vars=(x,), domain=RR)(p)
assert v.parent() is RR
assert ask(v>RR(129)) is True and ask(v<RR(131)) is True
print('polynomial value verified',flush=True)
d=fast_callable(body.diff(x), vars=(x,), domain=RR)(p)
assert d.parent() is RR
assert ask(d>RR(75)) is True and ask(d<RR(77)) is True
g=fast_callable(exp(-x*x), vars=(x,), domain=RR)(p)
assert g.parent() is RR
assert ask(g>RR(0)) is True and ask(g<RR(QQ(1)/QQ(10000000000))) is True
print('Gaussian and first derivative evaluation on owned Cauchy points verified',flush=True)
