from sage_extensions.all import *
from sage_extensions.categories.vector_bundles import _decided_no_real_zero
from sage.symbolic.ring import SR
xs=SR.var('a b c d e')
a,b,c,d,e=xs
specimens=[
    (1+a*a,True),
    (-1-a*a,True),
    (1+(a+b)**2,True),
    (-(1+(a+b)**2),True),
    ((a-1)**2+1,True),
    (-(a-1)**2-1,True),
    (a*a,False),
    (a*a-b*b+1,False),
    (a*b+1,False),
    (a*a+b+1,False),
    ((a+b)**2-1,False),
]
observed=[]
for q,expected in specimens:
    actual=_decided_no_real_zero(q,xs)
    observed.append((str(q),actual,expected))
    print(q,actual,expected,flush=True)
assert all(actual is expected for _,actual,expected in observed)
print('All exact quadratic zero decisions verified',flush=True)
