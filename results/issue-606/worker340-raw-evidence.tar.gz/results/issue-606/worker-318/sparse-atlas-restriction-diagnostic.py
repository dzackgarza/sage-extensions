from time import monotonic
from sage_extensions.all import *
sphere = SmoothManifolds().sphere(2)
north, south = sphere.atlas()['U_N'], sphere.atlas()['U_S']
x, y = north.coordinates()
for name in ('CUT_A','CUT_B','CUT_C'):
    sphere.chart_on_open_subset(name, 'x1 x2', 'U_N', (x*x+y*y,))
stated = tuple(sphere.transitions().keys())
t0=monotonic()
sub = sphere.open_submanifold(sphere.open_submanifold_inclusion(north.domain()))
print('restricted atlas time',monotonic()-t0,'stated edges',len(stated),'restricted edges',len(tuple(sub.transitions().keys())),flush=True)
assert set(sub.transitions().keys()) == set(stated), 'restriction must retain the stated edges, not eagerly create every composite'
before=tuple(sub.transitions().keys())
change = sub.transition('U_S','CUT_C')
assert tuple(change(RR(2)/RR(13),RR(3)/RR(13))) == (RR(2),RR(3))
assert tuple(change.inverse()(RR(2),RR(3))) == (RR(2)/RR(13),RR(3)/RR(13))
assert tuple(sub.transitions().keys()) == before
assert len(tuple(sub.coordinate_changes('U_S','CUT_C').keys())) == 1
print('original edges retained and actual composed coordinate change verified',flush=True)
