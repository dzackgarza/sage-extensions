from sage_extensions.all import *
from sage.rings.real_arb import RealBallField
from sage.rings.rational_field import QQ as native_QQ
from sage_extensions.categories.functions.real_functions import flat_exponential
from sage.symbolic.ring import SR

def cauchy(value):
    return RR.of_cauchy(Sets().Mor(NN, QQ)(lambda n: QQ(value) + QQ(1)/QQ(2)**int(n)))

a = cauchy(2)
b = cauchy(1)
x, y = SR.var('flat_test_x flat_test_y')
# F=a^-1 exp(-a/b); F_a=-3/4 exp(-2), F_b=exp(-2),
# F_ab=-exp(-2) at (2,1), F_bb=0 at (2,1).
expected = [
    ((0,0,1), RR(1)/RR(2)*RR(-2).exp()),
    ((1,0,1), -RR(3)/RR(4)*RR(-2).exp()),
    ((0,1,1), RR(-2).exp()),
    ((1,1,1), -RR(-2).exp()),
    ((0,2,1), RR.zero()),
]
def close(actual, desired):
    assert actual.parent() is RR
    enclosure = (actual-desired)._arb_(RealBallField(64))
    assert enclosure.is_finite()
    assert enclosure.lower().exact_rational() > -native_QQ(1)/2**20
    assert enclosure.upper().exact_rational() < native_QQ(1)/2**20

for (i,j,m), value in expected:
    close(RR._evaluate_formula(flat_exponential(i,j,m,x,y),(x,y),(a,b)), value)
print('mixed derivative values in the open half-plane verified', flush=True)

zero = cauchy(0)
for i,j in [(0,0),(1,0),(0,1),(1,1),(2,2)]:
    close(RR._evaluate_formula(flat_exponential(i,j,1,x,y),(x,y),(a,zero)), RR.zero())
# At a=0,b>0, m=0: F=1 and dF/da=-1/b; there is no pole.
close(RR._evaluate_formula(flat_exponential(0,0,0,x,y),(x,y),(zero,b)),RR.one())
close(RR._evaluate_formula(flat_exponential(1,0,0,x,y),(x,y),(zero,b)),-RR.one())
print('flat boundary and removable a=0 evaluation verified', flush=True)
circle=SmoothManifolds().sphere(1)
north=circle.atlas()['U_N']
south=circle.atlas()['U_S']
bump=circle.chart_bump('U_N',2,3)
for value,label,desired in [(0,'U_S',0),(1,'U_N',1),(2,'U_N',1),(3,'U_N',0)]:
    p=circle.point((cauchy(value),),label)
    close(bump(p),RR(desired))
print('public chart bump exact Cauchy values verified, including poles and support boundaries',flush=True)
