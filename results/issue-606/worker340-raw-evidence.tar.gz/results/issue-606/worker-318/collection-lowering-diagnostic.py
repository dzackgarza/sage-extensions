from pathlib import Path
from time import monotonic
from sage_extensions.all import *
from sage_extensions import language_runtime as runtime
from sageparse import lower, splice
from sageparse.extensions.research import EXTENSION
import re
selector=re.compile(r'test_(a_(bump_of_a_chart|derivation_is_local|derivation_of_a_one_chart|derivation_of_the_circle|frame_is_nowhere|frame_reads|pullback_agreement|section_is_stated|section_of_a_pullback|section_pulls_back|section_stated_on_a_cover|smooth_function_s_on_a_manifold|trivialization_reads|vector_field_pulls_back|submanifold_relates|chart_of_an_open_submanifold)|the_(frame_of_a_two_chart|functions_of_the_base_scale|proper_chart_domain|real_line_is_a_smooth|stereographic_transition_of_the_sphere|tangent_bundle_of_the_circle|tangent_bundle_restricts))')
paths=sorted(p for p in Path('tests/objects').glob('*.sage') if selector.match(p.name))
paths.append(Path('tests/objects/test_manifold_atlas_transition_expressions.sage'))
sources=[p.read_text() for p in paths]
counts=[0,0]
def old(node,context):
    counts[0]+=1
    if runtime._has_session_star_import(node,context) and runtime._assignment_uses_session_name(node,context):
        return splice(node,context)
    return runtime._RESEARCH_ASSIGNMENT(node,context)
def new(node,context):
    if runtime._assignment_uses_session_name(node,context):
        counts[1]+=1
        if runtime._has_session_star_import(node,context):
            return splice(node,context)
    return runtime._RESEARCH_ASSIGNMENT(node,context)
outputs=[]
for func in (old,new):
    start=monotonic()
    outputs.append([lower(source,extensions=(EXTENSION,runtime._EXTENSION,{'assignment':func}),products='explicit').python for source in sources])
    print(func.__name__,len(paths),'files',monotonic()-start,'seconds',flush=True)
assert outputs[0]==outputs[1]
print('full-source session-import scans',counts,'byte-identical generated Python',flush=True)
