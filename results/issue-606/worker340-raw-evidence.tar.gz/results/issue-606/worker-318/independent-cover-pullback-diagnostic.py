from sage_extensions.all import *
# Equatorial embedding: target inversion on (x,0) gives (1/x,0).
C=SmoothManifolds().sphere(1); S=SmoothManifolds().sphere(2)
N,T=C.atlas()['U_N'],C.atlas()['U_S']; x,y=N.coordinate(0),T.coordinate(0)
f=C.Mor(S)({('U_N','U_N'):(x,N.function_ring().zero()), ('U_S','U_S'):(y,T.function_ring().zero())})
B=S.tangent_bundle().pullback_along(f).sections()
assert B.vector_bundle().rank()==2 and B.base_manifold() is C
s=B.section({'U_N':(x,N.function_ring().one()),'U_S':(-y,y*y)})
for label,t,expected in [('U_N',0,(0,1)),('U_N',2,(2,1)),('U_S',0,(0,0)),('U_S',RR(1)/RR(2),(RR(-1)/RR(2),RR(1)/RR(4)))]:
    p=C.point((t,),label)
    assert tuple(s.components_at(p,label))==tuple(RR(v) for v in expected)
print('rank-two section on true global equatorial embedding verified at both poles and overlap',flush=True)
try:
    B.section({'U_N':(x,N.function_ring().one()),'U_S':(-y,y)})
except AssertionError:
    print('second-component incompatibility correctly refused',flush=True)
else:
    raise AssertionError('incompatible second component admitted')
# Independent frame section on disjoint label families (U vs V,W).
P=SmoothManifolds()(2,'independent cover plane'); U=P.chart('U','u v'); u,v=U.coordinates()
V=P.chart_on_open_subset('V','u v','U',(u,)); W=P.chart_on_open_subset('W','u v','U',(u-U.function_ring().one(),))
B=P.tangent_bundle().sections(); R=U.function_ring()
E=B.section({'U':(R.one(),R.zero())}); F=B.section({'U':(R.zero(),R.one())})
T=B.trivialized_by((E,F)).trivialization()
s=B.section({K.label():(K.coordinate(0)+K.coordinate(1),K.coordinate(0)-K.coordinate(1)) for K in (V,W)})
a,b=T.inverse(s)
assert a.parent() is P.smooth_functions() and b.parent() is P.smooth_functions()
back=T.forward((a,b))
for coords in ((0,3),(1,5),(2,7)):
    p=P(coords); expected=(RR(coords[0]+coords[1]),RR(coords[0]-coords[1]))
    assert (a(p),b(p))==expected
    assert tuple(back.components_at(p,'U'))==expected
print('independent-cover rank-two frame inverse and forward values verified',flush=True)
