from sage_extensions.all import *
from sage.rings.infinity import Infinity
A=C(Infinity,RR,RR)
a=Sets().Mor(NN,QQ)(lambda n: QQ(5)+QQ(1)/QQ(2)**int(n))
p=RR.of_cauchy(a)
assert p.cauchy_sequence() is a

def derivatives(chart,point,alpha):
    s=point.coordinates()[0]
    return (s**3+s, RR(3)*s*s+RR(1), RR(6)*s, RR(6))[alpha[0]] if alpha[0]<=3 else RR(0)
g=A.from_local_derivatives(derivatives)
v=g(p)
assert ask(v>RR(129)) is True and ask(v<RR(131)) is True
w=g.derivative()(p)
assert ask(w>RR(75)) is True and ask(w<RR(77)) is True
print('Cauchy-presented exact point evaluated and differentiated without a symbolic realization',flush=True)
