from sage_extensions.all import *
from sage_extensions.categories.manifolds import CoverageUndecided
import traceback

M = SmoothManifolds()(1, 'line')
U = M.chart('U', 't')
A = M.smooth_functions()
S = M.tangent_bundle().sections()
X = S.coordinate_vector_field(U, 0)
p = M((2,))
f = A(lambda p: RR(1))
assert f.parent() is A and f(p) == RR(1)
print('opaque constant admitted:', flush=True)
for label, check in (
    ('opaque constant acted on by d/dt', lambda: X(f)(p) == RR(0)),
    ('opaque constant acted on by zero', lambda: S.zero()(f)(p) == RR(0)),
    ('owned Der_R(A,A) is tangent section module', lambda: A.derivations() is S),
):
    try:
        assert check(), label
        print('PASS:', label, flush=True)
    except Exception:
        print('FAIL:', label, flush=True)
        traceback.print_exc()
# Same constant with an actual all-order differential witness.
g = A.from_local_derivatives(lambda chart, point, alpha: RR(1) if sum(alpha) == 0 else RR(0))
assert g(p) == RR(1) and X(g)(p) == RR(0) and X(X(g))(p) == RR(0)
print('PASS: constant with actual all-order witness', flush=True)
