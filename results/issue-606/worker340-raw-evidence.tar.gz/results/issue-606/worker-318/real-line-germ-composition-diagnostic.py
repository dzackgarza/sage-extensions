from sage_extensions.all import *
from sage.rings.infinity import Infinity
A = C(Infinity, RR, RR)
M = SmoothManifolds()(1, 'exact germ composition')
U = M.chart('U','x')
B = M.smooth_functions()
X = M.tangent_bundle().sections().coordinate_vector_field(U, 0)
# outer g(s)=s^3+s with genuine local derivatives, no symbolic expression

def outer_derivatives(chart, point, alpha):
    s = point.coordinates()[0]
    return (s**3+s, RR(3)*s*s+RR(1), RR(6)*s, RR(6))[alpha[0]] if alpha[0] <= 3 else RR(0)

def inner_derivatives(chart, point, alpha):
    t = point.coordinates()[0]
    return (t*t+RR(1), RR(2)*t, RR(2))[alpha[0]] if alpha[0] <= 2 else RR(0)

g = A.from_local_derivatives(outer_derivatives)
f = B.from_local_derivatives(inner_derivatives)
assert g(RR(5)) == RR(130)
print('real-line germ evaluation verified', flush=True)
h = g.compose(f)
p=M((2,))
assert h(p)==RR(130)
assert X(h)(p)==RR(304)
assert X(X(h))(p)==RR(632)
assert g.derivative()(RR(5))==RR(76)
assert g.derivative().derivative()(RR(5))==RR(30)
print('real-line germ differentiation and full germ composition verified', flush=True)
