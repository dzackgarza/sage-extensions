from sage_extensions.all import *
M=SmoothManifolds().sphere(1)
N,S=M.atlas()['U_N'],M.atlas()['U_S']
B=M.tangent_bundle().sections()
A=M.smooth_functions()
E=B.section({'U_N':(N.function_ring().one()+N.coordinate(0)**2,), 'U_S':(-(S.function_ring().one()+S.coordinate(0)**2),)})
def derivatives(chart,point,alpha):
    return RR(2) if alpha[0]==0 else RR(0)
g=A.from_local_derivatives(derivatives)
D=lambda f:g*E(f)
# The scale has no symbolic chart formula, so the inverse must use the germ construction.
V=B.from_derivation(D)
print('inverse section constructed',flush=True)
assert V.parent() is B
for label, t, val in [('U_N',0,2),('U_N',2,10),('U_S',0,-2),('U_S',RR(1)/RR(2),RR(-5)/RR(2))]:
    p=M.point((t,),label)
    print(label,t,tuple(V.components_at(p,label)),flush=True)
    assert tuple(V.components_at(p,label))==(RR(val),)
# f=2x/(1+x^2) equals 2y/(1+y^2) on the overlap y=1/x.
x,y=N.coordinate(0),S.coordinate(0)
f=M.smooth_function({'U_N':N.section_ratio(2*x,N.function_ring().one()+x*x),'U_S':S.section_ratio(2*y,S.function_ring().one()+y*y)})
for label,t,val in [('U_N',0,4),('U_N',2,RR(-12)/RR(5)),('U_S',0,-4),('U_S',RR(1)/RR(2),RR(-12)/RR(5))]:
    p=M.point((t,),label)
    assert V(f)(p)==D(f)(p)==RR(val)
print('both chart poles, overlap and derivation values verified',flush=True)
