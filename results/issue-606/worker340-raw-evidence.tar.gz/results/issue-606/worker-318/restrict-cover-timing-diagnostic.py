from time import monotonic
import faulthandler
from sage_extensions.all import *
faulthandler.dump_traceback_later(20, repeat=True)
start=monotonic()
def tick(name):
    global start
    now=monotonic(); print(name, now-start, flush=True); start=now
sphere=SmoothManifolds().sphere(2)
north,south=sphere.atlas()['U_N'],sphere.atlas()['U_S']
sphere.chart_on_open_subset('RESTRICT_A','x1 x2','U_N',(north.coordinate(0)**2+north.coordinate(1)**2,))
tick('cut registered')
domain=north.domain()
sub=sphere.open_submanifold(sphere.open_submanifold_inclusion(domain))
tick('submanifold')
S=sphere.tangent_bundle().sections()
section=S.section({'U_N':(north.coordinate(0),north.coordinate(1)),'U_S':(-south.coordinate(0),-south.coordinate(1))})
tick('section')
inclusion=sphere.open_submanifold_inclusion(sub)
tick('inclusion')
restricted=S.restrict(section,inclusion)
tick('restriction')
p=sub.atlas()['U_S'].domain()((RR(2)/RR(13),RR(3)/RR(13)))
tick('south point')
assert restricted.parent().vector_bundle().base_manifold() is sub
q=sub.atlas()['U_N'].domain()((2,3))
tick('north point')
assert restricted.components()['U_N'][0](q)==RR(2)
assert restricted.components()['U_N'][1](q)==RR(3)
assert section.components()['U_N'][0](q)==RR(2)
assert restricted.components()['U_S'][0](p)==-RR(2)/RR(13)
assert restricted.components()['U_S'][1](p)==-RR(3)/RR(13)
tick('all assertions')
faulthandler.cancel_dump_traceback_later()
