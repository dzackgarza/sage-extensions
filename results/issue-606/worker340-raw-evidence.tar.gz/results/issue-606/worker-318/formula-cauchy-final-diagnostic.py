from sage_extensions.all import *
from sage.rings.infinity import Infinity
from sage.repl.preparse import preparse
a=Sets().Mor(NN,QQ)(lambda n: QQ(5)+QQ(1)/QQ(2)**int(n))
p=RR.of_cauchy(a)
env=dict(globals())
from sageparse.preparser import runtime_namespace
env.update(runtime_namespace())
exec(preparse('f(t) = t^3+t\ng(s) = exp(-s^2)'),env)
A=C(Infinity,RR,RR)
f,g=A(env['f']),A(env['g'])
X=RR.tangent_bundle().sections().coordinate_vector_field(RR.identity_chart(),0)
for value,lower,upper in [(f(p),129,131),(f.derivative()(p),75,77),(X(f)(p),75,77),(X(X(f))(p),29,31)]:
    assert value.parent() is RR
    assert ask(value>RR(lower)) is True and ask(value<RR(upper)) is True
assert ask(g(p)>RR(0)) is True
assert ask(g(p)<RR(QQ(1)/QQ(10000000000))) is True
print('declared formulas, exact Cauchy-point evaluation, derivative and tangent action verified',flush=True)
