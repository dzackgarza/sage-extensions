from sage_extensions.all import *
from sage_extensions.categories.functions.smooth_germs import _bump_extended_coordinate, _local_radius, _function_jet
from sage.rings.real_arb import RealBallField
from sage.rings.rational_field import QQ as native_QQ
from sage.rings.real_mpfi import RealIntervalField
from time import monotonic
a=RR.of_cauchy(Sets().Mor(NN,QQ)(lambda n: QQ(5)+QQ(1)/QQ(2)**int(n)))
B=a._arb_(RealBallField(80))
I=RealIntervalField(80)(B)
assert I.lower()<5 and I.upper()>5
line=SmoothManifolds()(1,"Cauchy bump")
base=line.chart("U","x")
x=base.coordinate(0)
home=line.chart_on_open_subset("V","x","U",(x,),same_coordinates=True)
p=line.point((a,),"U")
start=monotonic()
radius=_local_radius(home,(a,))
print('certified radius',radius,'seconds',monotonic()-start,flush=True)
f=_bump_extended_coordinate(line,home,(a,),0)
assert f.parent() is line.smooth_functions()
assert ask(f(p)>RR(4)) is True and ask(f(p)<RR(6)) is True
jet=_function_jet(f,base,p,2)
assert ask(jet.coefficient((1,))>RR(QQ(9)/QQ(10))) is True
assert ask(jet.coefficient((1,))<RR(QQ(11)/QQ(10))) is True
assert f(line.point((0,),"U"))==RR(0)
assert f(line.point((10,),"U"))==RR(0)
print('exact centered bump, derivative, and vanishing outside support verified',flush=True)
from sage_extensions.categories.functions.smooth_germs import _flat_derivative
zero=RR.of_cauchy(Sets().Mor(NN,QQ)(lambda n: QQ(1)/QQ(2)**int(n)))
for order in range(5):
    value=_flat_derivative(zero,order)
    assert value.parent() is RR
    enclosure=value._arb_(RealBallField(64))
    assert enclosure.contains_zero()
    assert enclosure.upper().exact_rational() < native_QQ(1)/2**20
    assert enclosure.lower().exact_rational() > -native_QQ(1)/2**20
print('flat derivatives through order four at Cauchy zero have certified small enclosures',flush=True)
