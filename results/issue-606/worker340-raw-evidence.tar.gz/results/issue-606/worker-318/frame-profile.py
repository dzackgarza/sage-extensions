from sage_extensions.all import *
from sage.repl.preparse import preparse_file
from sageparse.preparser import runtime_namespace
from pathlib import Path
from time import monotonic
import cProfile,pstats
env=dict(globals());env.update(runtime_namespace())
path=Path('tests/objects/test_a_frame_of_rank_two_exhibits_its_module_isomorphism.sage')
exec(compile(preparse_file(path.read_text()),str(path),'exec'),env)
start=monotonic()
profile=cProfile.Profile()
profile.enable()
env['test_a_frame_that_is_not_the_coordinate_frame_inverts_its_matrix']()
profile.disable()
print('All original noncoordinate frame assertions passed; profiled seconds',monotonic()-start,flush=True)
pstats.Stats(profile).strip_dirs().sort_stats('cumulative').print_stats(45)
pstats.Stats(profile).strip_dirs().sort_stats('time').print_stats(30)
