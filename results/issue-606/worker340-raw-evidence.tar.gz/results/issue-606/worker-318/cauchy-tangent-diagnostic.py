from sage_extensions.all import *
from sage.rings.infinity import Infinity
M=RR
U=M.identity_chart()
A=M.smooth_functions()
S=M.tangent_bundle().sections()
X=S.coordinate_vector_field(U,0)
a=Sets().Mor(NN,QQ)(lambda n: QQ(5)+QQ(1)/QQ(2)**int(n))
p=RR.of_cauchy(a)
def derivatives(chart,point,alpha):
    s=point.coordinates()[0]
    return (s**3+s, RR(3)*s*s+RR(1), RR(6)*s, RR(6))[alpha[0]] if alpha[0]<=3 else RR(0)
g=A.from_local_derivatives(derivatives)
assert ask(g(p)>RR(129)) is True
v=X(g)(p)
assert ask(v>RR(75)) is True and ask(v<RR(77)) is True
w=X(X(g))(p)
assert ask(w>RR(29)) is True and ask(w<RR(31)) is True
print('coordinate derivation at a Cauchy-presented point returns 76, second derivative 30',flush=True)
