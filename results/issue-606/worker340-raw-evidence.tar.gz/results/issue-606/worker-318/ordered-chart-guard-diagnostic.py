from sage_extensions.all import *
M = SmoothManifolds()(1, 'nested chart domains')
U = M.chart('U', 't')
t = U.coordinate(0)
V = M.restricted_chart('U', (t,))
v = V.coordinate(0)
# (1/t) is smooth on the cut chart t!=0, not at the excluded point.
w = V.section_ratio(V.function_ring().one(), v)
W = M.restricted_chart('U', (t, w))
p = M.point((0,), 'U')
assert p.coordinates()[0] == RR(0)
q = W.domain().point((2,), W.label())
assert q.coordinates()[0] == RR(2)
try:
    W.domain().point((0,), W.label())
except (ValueError, AssertionError):
    pass
else:
    raise AssertionError('the proper cut wrongly includes zero')
print('ambient point at zero and restricted point at two are valid; restricted zero is rejected',flush=True)
