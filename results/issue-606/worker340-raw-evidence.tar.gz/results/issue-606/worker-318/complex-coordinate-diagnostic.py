from time import monotonic
import faulthandler
from sage_extensions.all import *
faulthandler.dump_traceback_later(15, repeat=True)
start=monotonic()
def tick(label):
    global start
    now=monotonic()
    print(label, now-start, flush=True)
    start=now
line=ComplexManifolds().affine_space(1,name="C")
tick('affine space')
chart=line.atlas()["standard"]
tick('chart')
functions=chart.function_ring()
tick('function ring')
point=line((2*I,),chart_label="standard")
tick('point')
assert functions.domain() is chart.domain()
assert chart.coordinate(0).parent() is functions
tick('coordinate parent')
assert chart.coordinate(0)(point)==2*I
tick('coordinate value')
assert chart.coordinate(0)(point).parent() is CC
assert tuple(chart(point))==(2*I,)
tick('all original equations')
faulthandler.cancel_dump_traceback_later()
