import sage.all
from time import monotonic
import cProfile, pstats
profile = cProfile.Profile()
start = monotonic()
profile.enable()
from sage_extensions.all import *
profile.disable()
print('session star import profiled wall seconds', monotonic()-start, flush=True)
pstats.Stats(profile).strip_dirs().sort_stats('cumulative').print_stats(60)
pstats.Stats(profile).strip_dirs().sort_stats('time').print_stats(35)
