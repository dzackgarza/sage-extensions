from sage_extensions.all import *
import inspect, traceback
for field in (RR, CC, QQbar, QQ):
    print(field, type(field), 'cardinality', field.cardinality(), flush=True)
    for name in ('cardinality','_cardinality_decision'):
        method = getattr(field,name)
        print(name, getattr(method,'__module__',None), getattr(method,'__qualname__',None), flush=True)
print('QQbar categories',QQbar.category(), 'ordered RR',RR in OwnedOrderedRings(), flush=True)
print('QQbar -1 square',QQbar(-1).is_square(),flush=True)
R=QQ.matrix_space(2)
print('matrix category',R.category(),flush=True)
try:
    Z=R.center(); print('center',Z,'base ring', Z.base_ring(), 'rank',Z.module_rank(),flush=True)
    print('center one',Z.inclusion()(Z.one()), '3I',3*R.one() in Z, 'E12', R.matrix_unit(0,1) in Z, flush=True)
except Exception: traceback.print_exc()
