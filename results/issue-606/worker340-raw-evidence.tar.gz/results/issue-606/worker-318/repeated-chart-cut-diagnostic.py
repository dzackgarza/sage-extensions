from sage_extensions.all import *
from sage_extensions.categories.manifolds import _engine_manifold_chart
M = SmoothManifolds()(1, 'canonical open chart restriction')
U = M.chart('U', 'x')
x = U.coordinate(0)
engine = _engine_manifold_chart(U)
initial = len(engine._subcharts)
first = M.restricted_chart('U', (x,))
for _ in range(8):
    again = M.restricted_chart('U', (x,))
print('subcharts before/after:', initial, len(engine._subcharts), flush=True)
assert first is again, 'the same chart and defining open conditions must not construct a new submanifold'
assert len(engine._subcharts) == initial+1
other = M.restricted_chart('U', (x-U.function_ring().one(),))
assert other is not first
assert first.domain().point((1,),first.label()).coordinates()[0] == RR(1)
print('same cut retained; different cut distinct',flush=True)
