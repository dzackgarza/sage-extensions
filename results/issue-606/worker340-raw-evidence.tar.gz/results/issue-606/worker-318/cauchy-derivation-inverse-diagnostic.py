exec(open('results/issue-606/worker-318/cauchy-tangent-diagnostic.py').read())
# h(t)=t^3+t, Y=h d/dt. Its induced derivation on the identity coordinate is h.
Y=S.scalar_multiple(g,X)
D=lambda f:Y(f)
Z=S.from_derivation(D)
coefficient=tuple(Z.components_at(p))[0]
assert ask(coefficient>RR(129)) is True and ask(coefficient<RR(131)) is True
value=Z(g)(p)
assert ask(value>RR(9879)) is True and ask(value<RR(9881)) is True
print('recovered derivation coefficient 130, action on g 9880',flush=True)
