from sage_extensions.all import *
from sage_extensions.owned_category import _category_provider_order_key, _declared_category_linearization, OwnedCategoryMixin
from sage.misc.c3_controlled import C3_sorted_merge
from time import monotonic

def previous(category):
    cache = {}
    def linearize(node):
        known = cache.get(id(node))
        if known is not None:
            return known
        parents=tuple(sorted(node.super_categories(),key=_category_provider_order_key,reverse=True))
        sequences=[list(linearize(parent)) for parent in parents]
        sequences.append(list(parents))
        merged,_=C3_sorted_merge(sequences,key=_category_provider_order_key)
        result=(node,*merged)
        cache[id(node)]=result
        return result
    return linearize(category)

categories = [ZZ.category(),QQ.category(),RR.category(),CC.category(),SmoothManifolds(),
              Modules(RR), RR.tangent_bundle().sections().category()]
seen={}
def visit(node):
    if id(node) in seen:
        return
    seen[id(node)]=node
    for parent in node.super_categories():
        visit(parent)
for c in categories:
    visit(c)
for node in seen.values():
    old, new=previous(node), _declared_category_linearization(node)
    assert len(old)==len(new) and all(x is y for x,y in zip(old,new,strict=True))
    if isinstance(node,OwnedCategoryMixin):
        assert new is _declared_category_linearization(node)
print('Original controlled provider order preserved on',len(seen),'actual categories; owned tuples reused',flush=True)
