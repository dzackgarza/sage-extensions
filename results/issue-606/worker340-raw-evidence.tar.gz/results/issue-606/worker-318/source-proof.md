# Local smooth functions and the tangent-section equivalence (#606, #198)

## Original contract

Read the live issues #606 and #198, and the owner-authored TODO at
`d5b8b78:TODO.md` (line 1876). The required algebra is the algebra of real
smooth functions, not a ring of symbolic or analytic functions, and the
tangent section module is to realize its real derivations. The construction
of pullback sections and the global-frame isomorphism must respect actual
source and target domains, independently of presentation cover.

## Mathematical proof

Assume a smooth finite-dimensional Hausdorff manifold M as in Lee,
*Introduction to Smooth Manifolds*, 2nd ed. (Springer, 2013),
Propositions 3.8, 8.14, 8.15; use Proposition 2.25 for the existence of
smooth bump functions.

Let D be an R-linear derivation of the full algebra A=C^infty(M).
If h vanishes on a neighborhood of p, take a bump b supported in that
neighborhood and equal to 1 near p. Then bh=0, so Leibniz at p gives
0=D(bh)(p)=Dh(p). Thus Df(p) depends only on the germ at p.
For any chart x:U -> O and p in U choose a closed Euclidean ball
centered at x(p) and compactly contained in O. Choose a smooth radial
cutoff equal to one on a smaller ball and zero outside the larger ball.
The product with x_i, extended by zero outside U, is a global smooth
function X_i: its support is compact in U, hence closed in M. The
extension agrees with zero on an open neighborhood of each point
outside that support. No compactness of M or finite spanning family is
used.

In a neighborhood on which X_i=x_i set v_i=D(X_i). These are smooth
and independent of the cutoff, by locality at every point of that
neighborhood. The first-order smooth Hadamard formula for a chart germ
f at q writes f-f(q)=sum_i (x_i-x_i(q))g_i with
g_i(q)=partial_i f(q); the g_i may be extended locally using the same
bump construction. Evaluation at q of D kills constants and products
of functions vanishing at q. Hence
Df(q)=sum_i v_i(q) partial_i f(q).
Applying the same identity to bump-extended coordinates y_j of another
chart yields w_j=sum_i (partial_i y_j)v_i on the actual overlap. This
is precisely the tangent coordinate transition law, and the local
smooth coefficients glue to a unique smooth vector field V.
Conversely, V acts as a real derivation by the product rule; smoothness
and coordinate independence follow from the smooth coefficient functions
and chain rule. The two maps are inverse: the displayed formula
recovers D, and applying the derivation of V to bump-extended
coordinates recovers every coefficient of V. Both maps are A-linear.

A finite family of compactly supported functions on a positive-dimensional
noncompact M cannot span the cotangent fibres: outside the compact union
of supports every differential vanishes. The noncompact regression tests
the old invalid requirement. The optional sphere optimization uses the
standard embedding coordinates in north stereographic coordinates
u=2x/(1+|x|^2), z=(|x|^2-1)/(1+|x|^2), with the opposite sign of z in
south coordinates. Local left inverses x=u/(1-z), y=u/(1+z) prove
injectivity of its differential, hence the coordinate differentials span.

An all-order local derivative datum need not be analytic. For finite
order k the normalized Taylor coefficients define the polynomial in
the truncated algebra R[t_1,...,t_n]/(t)^(k+1). Taylor's theorem and
Leibniz identify addition and multiplication with those of polynomials;
composition substitutes jets of coordinate functions with their constant
terms removed. This follows by the Taylor formula with remainder
o(|t|^k), and smoothness of the inner map, whose displacement is O(|t|).
For a nonzero constant coefficient a, write f=a(1-q) with q nilpotent;
f^(-1)=a^(-1) sum_{i=0}^k q^i. Partial differentiation is coefficient
differentiation into order k-1. These are exact jet operations at each
point, not finite point samples and not convergence of Taylor series.
The flat function regression uses f(t)=exp(-1/t) for t>0, zero otherwise:
for t>0 its nth derivative is exp(-u)P_n(u), u=1/t, where
P_0=1, P_(n+1)=u^2(P_n-P'_n). Each polynomial times exp(-u) tends to
zero as u tends to infinity. Inductively every derivative extends by
zero; the function is smooth and has zero Taylor series at zero but
is not identically zero on any neighborhood of zero.

For pullback f:N -> M and E -> M, local section coordinates over N
are relative to the frame of E at f(q); a change of E-frame G has
coefficients G(f(q))a(q) (Tu, *Differential Geometry*, Proposition 20.7).
For E=TM, G is the derivative of the target coordinate transition,
not df. Refine source pieces on intersections with inverse images of
the actual target domains. The usual cocycle condition composes these
changes. Pulling back a section gives smooth local coefficients by
composition and respects these transition laws. Independent pullback
sections are specified by their own compatible coefficient functions.
Iterated pullbacks compose the original target maps; the same formula
applies to the original tangent fibres.

For a rank-r global frame E_i, on each common local refinement express
every frame section and a section V in the same fibre frame. The matrix
B of columns E_i is invertible at every point by the frame hypothesis.
The coordinate column B^(-1)V is smooth since its entries are Cramer
quotients with nowhere-zero denominator. Under any other local fibre
frame, B'=GB and V'=GV for an invertible smooth matrix G, so the
coordinate column is unchanged. These functions glue over all overlaps.
The map (a_i) -> sum_i a_i E_i is inverse to this reading by pointwise
basis uniqueness and is A-linear. This proof does not require that the
initial covers of the sections and frame coincide.

## Defective original fixture

The original test_a_section_of_a_pullback_is_stated_on_its_own_base.sage
asserts that an equator reflection on S^2 has same-chart coordinate
formula I(x)=x/|x|^2 on both stereographic charts, and that a constant
tuple (1,0) in both target frames describes one section. These formulas
omit both poles, so do not describe a map on S^2 by their actual domains.
Moreover, for x=(2,3), the target Jacobian J_I(I(x)) applied to (1,0)
has first component -x_1^2+x_2^2=5, not 1. The literal assertion is
inconsistent with the mathematical pullback law. Its actual failure is
retained in pullback-germs-candidate.log. The corrected fixture uses the
true reflection between opposite charts (identity coordinates including
both poles); its radial coefficient functions -x and y glue because
dI_x(x)=-I(x). Its negative case uses the same sign on both charts.

## Remaining implementation boundary (not a completion claim)

All-order derivative data supplies an extensional presentation of every
mathematically smooth function, if the requisite local data are supplied.
An evaluation-only callable does not supply a derivative representation.
No uniform finite-query algorithm can compute derivatives from evaluations
alone: run such an algorithm on the zero function at 0, to error <1/3.
Its finitely many nonzero query points are disjoint from a sufficiently
small neighborhood of zero. A smooth function t*chi(t/epsilon) with chi=1
near zero and support in that neighborhood has the identical queried
values but derivative 1 at zero. Thus the same output cannot approximate
both derivatives. The opaque-function admission test now checks admission,
not derivative availability. The remaining implementation obligation is
an adequate effective differential representation at that boundary, not
a theorem that all opaque programs are differentiable.

The present exact jet implementation still requires computable local
chart membership/transition and bump-support certificates. It does not
implement a locator for arbitrary infinite indexed covers or arbitrary
opaque smooth chart restrictions. The symbolic cover and overlap
decisions are not complete for general smooth functions. The explicit
hypothesis route (check=False) uses the mathematical cover and agreement
conditions rather than pretending to decide arbitrary smooth equality.
These limitations must not be described as satisfaction of the full
original #198/#606 contract.
