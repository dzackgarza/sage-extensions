from sage_extensions.all import *
sequence=Sets().Mor(NN,QQ)(lambda n: QQ(5)+QQ(1)/QQ(2)**int(n))
x=RR.of_cauchy(sequence)
plane=SmoothManifolds()(2,"Exact plane")
chart=plane.chart("U","x y")
point=plane.point((x,RR(2)),"U")
assert point.parent() is plane
assert ask(point.coordinates()[0]>RR(4)) is True
assert ask(point.coordinates()[0]<RR(6)) is True
assert point.coordinates()[1]==RR(2)
u,v=chart.coordinates()
f=plane.smooth_function({"U":u*u+v*v})
value=f(point)
assert value.parent() is RR and ask(value>RR(28)) is True and ask(value<RR(30)) is True
X=plane.tangent_bundle().sections().coordinate_vector_field(chart,0)
value=X(f)(point)
assert value.parent() is RR and ask(value>RR(9)) is True and ask(value<RR(11)) is True
print("Owned exact Cauchy point, polynomial value 29 and derivative 10 verified",flush=True)
