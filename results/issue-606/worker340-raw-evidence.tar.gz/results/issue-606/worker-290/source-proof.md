# Pullback sections: transport, domains, and coverage

## Mathematical construction

Let \(f:N\to M\) be smooth, let \(\pi:E\to M\) be a smooth real vector bundle of rank \(r\), and let \(s\) be a smooth section over an open set \(O\subseteq M\). Define
\[
f^*E=\{(q,e)\in N\times E:\pi(e)=f(q)\},\qquad
(f^*s)(q)=(q,s(f(q))).
\]
This retains the section's definition on all of \(f^{-1}(O)\). Tu's Theorem 20.6 and Proposition 20.7 construct the smooth pullback bundle and identify its transitions [Tu17, pp. 178–179]. Computed local descriptions must preserve their domains; their availability alone does not establish that they cover this global domain.

Suppose representation \(i\) of \(f\) uses charts \(A_i,U_i\) and an actual open domain \(D_i\subseteq A_i\cap f^{-1}(U_i)\). Different pieces may use the same chart pair. This domain convention is essential in Lee's Proposition 2.5 [Lee12, p. 35]. Let \(s_\beta\) denote section components in frame \(V_\beta\), defined on \(S_\beta\subseteq V_\beta\). Write \(J_{V\to U}\) for the matrix converting fibre components from frame \(V\) to frame \(U\).

If a represented transition path \(p:U_i\leadsto V_\beta\) is valid on \(P_p\subseteq U_i\cap V_\beta\), its pullback description is
\[
W_{i\beta p}=D_i\cap f^{-1}(S_\beta\cap P_p),\qquad
c_{i\beta p}(q)=J_{V_\beta\to U_i}(f(q))s_\beta(f(q)).
\]
Here the component evaluation includes conversion to \(V_\beta\)-coordinates. When the stored path matrix converts \(U_i\)-components to \(V_\beta\)-components, its inverse supplies \(J_{V_\beta\to U_i}\), on that same path domain. For independently indexed bundle frames and coordinate charts, also intersect with the frame domains.

Every factor is smooth on \(W_{i\beta p}\). Section compatibility and the transition cocycle give, on actual common domains,
\[
c_{j\gamma p'}(q)=J_{U_i\to U_j}(f(q))c_{i\beta p}(q).
\]
Indeed, insert \(s_\beta=J_{V_\gamma\to V_\beta}s_\gamma\) and use
\(J_{V_\beta\to U_i}J_{V_\gamma\to V_\beta}=J_{V_\gamma\to U_i}\). Source-coordinate changes merely re-express these functions. Lee's bundle chart and local-frame results justify smoothness, and his gluing lemma applies once
\[
f^{-1}(O)=\bigcup_{i,\beta,p}W_{i\beta p}
\]
has been established [Lee12, Corollary 2.8, p. 35; Lemmas 10.5–10.6, pp. 252–254; Proposition 10.22, p. 260]. The glued value is exactly \((q,s(f(q)))\).

For a covering map presentation, a covering section presentation on \(O\), and transitions covering the actual endpoint overlaps, this equality of domains follows directly. Given \(q\in f^{-1}(O)\), choose \(i\) with \(q\in D_i\), then \(\beta\) with \(f(q)\in S_\beta\), and a represented transition domain \(P_p\) containing \(f(q)\). Thus \(q\in W_{i\beta p}\). Conversely, every such \(W_{i\beta p}\) is contained in \(f^{-1}(O)\). This is the general inverse-image cover law; neither matching labels nor global extensions enter it.

No differential \(df\) occurs: the fibre is \(E_{f(q)}\), of dimension \(r\), independently of \(\dim N\). For a tangent bundle, \(J\) is the derivative of a target coordinate change, not of \(f\).

## Transition paths retain every restriction

For consecutive coordinate transitions \(F_j:\Omega_j\to\text{next chart}\), let \(F_{[0]}=\operatorname{id}\) and \(F_{[j]}=F_j\circ F_{[j-1]}\). The composite domain is
\[
\Omega_p=\bigcap_{j=1}^kF_{[j-1]}^{-1}(\Omega_j).
\]
Each guard is evaluated only after its preceding transitions are defined. The fibre matrix is the ordered product
\[
K_p(x)=K_k(F_{[k-1]}(x))\cdots K_2(F_{[1]}(x))K_1(x).
\]

For a finite valid chart-and-frame graph, all simple paths cover exactly the union of all represented finite-path domains. To prove this, remove a cycle from any path. At every point of the original domain, that cycle returns the same coordinates and components in the same chart and frame. Removing it leaves subsequent inputs unchanged and therefore only enlarges the path domain. Repeating produces a simple path with the same value on the original domain. The reverse inclusion is immediate.

This proves completeness relative to represented paths, not equality with the full geometric endpoint overlap. Conversely, any positively certified subfamily covering that overlap suffices, whether or not path enumeration was exhaustive.

## Positive coverage certificates

Work on a coordinate domain \(\Omega\) of a known covering atlas. For candidate piece \(i\), retain the complete ordered nonvanishing guards, including inherited map restrictions, transition restrictions, and denominator exclusions. If its rational guards are \(n_{ij}/d_{ij}\ne0\), form
\[
P_i=\prod_j n_{ij}d_{ij},
\]
including any additional factors needed when clearing denominators. Each individual numerator and denominator is retained before multiplying; cancellation between guards cannot erase a restriction.

The required implication is
\[
\Omega\cap\{P_i\ne0\}\subseteq W_i.
\]
It follows by checking the guards in order: the retained denominators and numerators are nonzero, so each next expression is defined and its guard holds. Extra denominator exclusions may conservatively exclude points at removable singularities, so equality need not hold. Simplification that discards an inherited exclusion does not satisfy this argument.

Coverage follows from any verified identity
\[
1=\sum_i a_iP_i,
\]
with coefficients defined throughout \(\Omega\): all \(P_i\) cannot vanish at one point. A polynomial unit-ideal computation supplies polynomial coefficients. A nonzero constant sum is a special case. Alternatively, a proved strict inequality \(\sum_iP_i^2>0\) on \(\Omega\), for example an identity with a positive constant plus squares, gives the same conclusion. Thus \(\Omega\) is covered by subsets of the actual pieces, without assuming exhaustive paths. Repeat on each chart of the known cover. Failure to find a sufficient certificate does not prove noncoverage. For nonrational smooth guards, identities among the actual smooth guard functions can likewise certify coverage.

### Two cuts on the sphere

Let \(U,V\) be stereographic charts on \(S^2\), with \(v=u/|u|^2\). The point \(u=0\) lies outside \(V\). Put
\[
C_1=V|_{\{|v|^2-1\ne0\}},\qquad
C_2=V|_{\{|v|^2-2\ne0\}}.
\]
Their union is \(V\), not \(S^2\). With \(q=|u|^2\), the transported guards are \((1-q)/q\ne0\) and \((1-2q)/q\ne0\), retaining \(q\ne0\). Actual domain generators are \(q(1-q)\) and \(q(1-2q)\), up to redundant powers of \(q\). Both vanish at \(u=0\); their cozero union is \(\{q\ne0\}\).

Dropping denominators falsely yields the unit identity
\(2(1-q)-(1-2q)=1\). The correct identity is
\(2q(1-q)-q(1-2q)=q\), which certifies coverage only where \(q\ne0\).

In contrast, two paths through the restrictions \(x\ne0\) and \(x-1\ne0\) of a global plane chart really cover it, since \(x-(x-1)=1\). This remains true for a second global shear chart \((x,y+x^2)\). A constant image with \(x=0\) requires the second path.

## A constant map from dimension one with a smooth nonanalytic section

On \(M=\mathbb R^2\), let \(U=(x,y)\) and \(V=(u,v)=(x,y+x^2)\); both charts cover \(M\). Let \(B(u,v)\) be a smooth cutoff equal to one on the closed radius-two ball and zero outside the radius-three ball, as constructed from the flat smooth function below. The section stated only in \(V\) is \(s_V=(B,0)^T\). For \(f:\mathbb R\to M\), \(f(t)=(1,0)\) in \(U\), the image has \(V\)-coordinates \((1,1)\), so \(B(f(t))=1\). Since
\[
J_{V\to U}(u,v)=\begin{pmatrix}1&0\\-2u&1\end{pmatrix},
\]
the pullback has \(U\)-frame components \((1,-2)^T\) at every source point. Its fibre rank remains two, although the source dimension is one. This calculation uses the globally defined nonanalytic section supplied on \(V\), with no requirement that the map's target label occur in its component dictionary.

## Smooth pieces in the same chart pair

Let \(b(t)=0\) for \(t\le0\) and \(b(t)=e^{-1/t}\) otherwise; it is smooth [Lee12, Lemma 2.20, p. 41]. Define
\[
H(t)=\frac{b(4-t^2)}{b(4-t^2)+b(t^2-1)},\qquad
K(t)=\frac{b(9-t^2)}{b(9-t^2)+b(t^2-4)}.
\]
The denominators are positive everywhere. Thus \(H\) equals one on \(|t|\le1\) and zero on \(|t|\ge2\), whereas \(K\) equals one on \(|t|\le2\) and zero on \(|t|\ge3\).

In the same chart pair, prescribe zero on \(D_1=\{H\ne0\}\) and \(1-K\) on \(D_2=\{1-H\ne0\}\). The identity \(H+(1-H)=1\) proves coverage. On the overlap \(1<|t|<2\), both formulas vanish, so they glue to the smooth function \(1-K\). Their unrestricted formulas disagree at \(t=3\). At \(t=2\), the glued function has all derivatives zero but is positive immediately to the right, so it is not analytic there. Consequently, global symbolic equality of unrestricted formulas is not the smooth overlap law.

## Nested pullbacks and frames

For smooth \(g:P\to N\), the canonical isomorphism
\[
g^*(f^*E)\longrightarrow(f\circ g)^*E,\qquad
(p,(g(p),e))\longmapsto(p,e)
\]
sends \(g^*(f^*s)\) to \((f\circ g)^*s\), directly from their pointwise definitions. Local descriptions restrict to the actual domains of \(g\) intersected with \(g^{-1}(W_{i\beta p})\), retaining additional coordinate-transition restrictions. This proves the nested transport law with unchanged fibre rank.

For \(r\) sections, form the square coefficient matrix \(S_U\) only after expressing every column in one common fibre frame on a common actual domain. Then
\[
S_U=J_{V\to U}S_V,\qquad
\det S_U=(\det J_{V\to U})\det S_V.
\]
Because the transition determinant is nowhere zero there, the nonvanishing locus is frame-independent. It characterizes a local frame by ordinary linear algebra. On that locus the inverse matrix is smooth by the adjugate formula. Pullback composes the determinant with \(f\). Combining columns from different frames or unrelated local domains does not compute this invariant.

## Equality and inequality on actual domains

Equal component tuples in one fibre frame prove equality only on the common actual domain. If these domains cover the base, their pointwise equalities prove equality of sections. One proper open set is insufficient for smooth sections, as the cutoff example shows.

There is also a limited exact inequality certificate. Suppose a source chart has coordinate image all of \(\mathbb R^n\), all ordered common-domain guards are rational with rational polynomial numerators and denominators, and one coefficient residual is of the same kind. Form the product of every guard numerator and denominator and the residual numerator and denominator, without canceling factors between guards. If this polynomial is nonzero, there exists a point where it is nonzero. Indeed, a nonzero real polynomial cannot vanish identically on a nonempty open box: induction on the number of variables reduces this to the fact that a nonzero univariate polynomial has finitely many roots. At that point every guard is defined and nonzero and the residual is nonzero. The two sections are therefore unequal. This argument concerns only the certified rational expressions on their actual domains; it imposes no analyticity on smooth sections. The implementation declines this certificate for unsupported guards or uncertified coordinate domains.

## Canonical restriction of vector fields

For an actual open inclusion \(i:U\hookrightarrow M\), \(di_q:T_qU\to T_{i(q)}M\) is an isomorphism: in a restricted ambient chart it is the identity matrix. Hence the canonical vector-field restriction is
\[
X|_U(q)=(di_q)^{-1}X(i(q))\in T_qU.
\]
It acts on a smooth function on \(U\) by the ordinary local coordinate derivative, which depends only on the function's germ at \(q\); a global extension to \(M\) is unnecessary. This operation returns a section of \(TU\), while the separately chosen pullback \(i^*TM\) retains \(i\). The implementation preserves the complete private derivation realization by restricting the original engine vector field to the actual open subset. It does not reconstruct a global derivation from an uncertified partial coefficient cache. Cached coefficients use the inherited domain frames, and default point evaluation requests the frame corresponding to the domain point's chart.

## Scope and remaining implementation obligations

This proves the specified pullback construction and its domain laws; it is not a completion claim for all of #606 or #198. Ordinary `_chartwise_family_agrees` still has a global symbolic residual rather than the full smooth overlap law. The full \(C^\infty\) function-restriction baseline failures remain distinct obligations. Trivialization matrix operations require a common fibre frame and support for local covering presentations. These obligations require implementation and direct evidence; the preceding proof does not establish that current code meets them.

## Owner implementation review

The public pullback owner is SmoothSectionModules.ParentMethods.pullback_of. It
now reads every actual map piece, retaining source chart, ordered domain guards,
and ultimate fibre frame for every computed coefficient tuple. The chosen
pullback retains its map even for an identity or open inclusion. Its defining
evaluation is the source section evaluated at the image point. Restrictions,
addition, negation, scalar multiplication, zero, and nested pullbacks retain that
definition. The tangent-field restriction operation additionally uses the
canonical TU identification and retains its derivation realization, as proved
above; an arbitrary-map pullback is not identified with the source tangent
bundle.

SmoothManifoldMor accepts distinct local indices for one source/target chart
pair. Its coefficients are owned smooth functions on actual restricted open
submanifolds. Quotient denominator domains are retained before symbolic
lowering. Composition keeps every computed local intersection and retains the
global composition of its point maps. Neither the input map nor a computed
dictionary is replaced by an arbitrary globally extended chart formula.

ManifoldAtlasTransition.then retains the intersection of all edge domains.
Composites are not registered back into the base transition table.
The existing private Sage chart-restriction adapter realizes the separate
coefficient domains; the owned base atlas labels and transitions are unchanged.
Ordered guards are assigned to their preceding domains, so a reciprocal is
never introduced as a globally smooth function on a chart containing its pole.
The ordinary vector-field adapter likewise supplies each coefficient to Sage
as a scalar field with an explicit chart on that chart's domain, rather than
coercing a raw coordinate expression as a chart-independent scalar.

The existing chart-cover owner now includes all represented path guards and
each rational guard's numerator and denominator. Equality uses actual
intersections of coefficient domains in matching source coordinates and fibre
frames, and returns true only after certifying a cover. Returned component
dictionaries are copies, preserving their consistency with the defining
evaluation. Rational inequality uses the nonempty-domain certificate proved
above; arbitrary smooth residuals are not treated as globally analytic.

The matrix consumers now check common fibre frames and actual local coverage.
A description on a proper open subset is not re-raised on a whole chart without
a covering certificate. This prevents a false basis certificate from two copies
of one vector expressed in swapped coordinate frames. It does not implement
every missing frame conversion or the full smooth trivialization interface.

The only exposed non-pullback bundle factory in this source is the tangent
bundle; further bundles here are iterated pullbacks. This is why coordinate
Jacobians compute the actual bundle transition matrices in these operations.
The general bundle proof above uses the bundle's transition matrices and does
not assert that an arbitrary bundle transition is a Jacobian.

## Validation

The exact commands, direct red/green results, baseline provenance, and limitations are recorded in validation.txt beside this proof. The candidate is based on e2803c36a8a316337071ba90551ce770d36b2b86; its exact commit identifier is reported in the worker handoff.

## References

- **[Lee12]** John M. Lee, *Introduction to Smooth Manifolds*, second edition, Graduate Texts in Mathematics 218, Springer, 2012. Proposition 2.5 and Corollary 2.8, p. 35; Lemma 2.20, p. 41; Lemmas 10.5–10.6, pp. 252–254; Proposition 10.22, p. 260. [Publisher](https://link.springer.com/book/10.1007/978-1-4419-9982-5); [inspected text](https://studylib.net/doc/26084601/lee-smooth-manifolds).
- **[Tu17]** Loring W. Tu, *Differential Geometry: Connections, Curvature, and Characteristic Classes*, Graduate Texts in Mathematics 275, Springer, 2017. Section 20.4, pp. 177–179; Theorem 20.6 and Proposition 20.7, pp. 178–179. [DOI](https://doi.org/10.1007/978-3-319-55084-8).
- **[Sage]** SageMath reference manual, [Scalar Fields](https://doc.sagemath.org/html/en/reference/manifolds/sage/manifolds/scalarfield.html) and [Chart Functions](https://doc.sagemath.org/html/en/reference/manifolds/sage/manifolds/chart_func.html). The private coefficient adapter supplies an explicit chart-to-expression dictionary on the chart's domain.
